package com.logprocessor;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.logprocessor.model.LogMessage;


public class TestDataGenerator {
	
public static void main(String[] args) throws JsonProcessingException {
	
	ObjectMapper mapper = new ObjectMapper();
	LogMessage message = new LogMessage("123","State","host");
	
	/*String jsonInString = mapper.writeValue(w, value);
	
	System.out.println(jsonInString);*/
}	
	

}
