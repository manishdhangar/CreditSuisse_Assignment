package com.logprocessor;

import java.security.InvalidParameterException;
import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application {
  
	public static void main(String[] args) throws Exception {
		// validateInput(args);
		System.setProperty("file.path",	"C:\\Users\\manis\\Downloads\\log-file-processor\\log-file-processor-master\\src\\test\\resources\\logData.txt");
		SpringApplication.run(Application.class, args);
	}

	
}
