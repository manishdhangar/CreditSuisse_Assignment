# log-file-processor
Application Process logs files and Flag any long events that take longer than 4ms with a column in the database called "alert"
